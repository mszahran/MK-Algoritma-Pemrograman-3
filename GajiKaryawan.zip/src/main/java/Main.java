import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Array Gaji berdasarkan golongan
        int[] gaji = {5000000, 6500000, 9500000};

        // Array persentase lembur
        int[] persenLembur = {30, 32, 34, 36, 38};

        // Input dari user
        Scanner scanner = new Scanner(System.in);
        System.out.print("Masukkan Golongan (A/B/C): ");
        String golongan = scanner.next().toUpperCase();
        System.out.print("Masukkan Jam Lembur: ");
        int jamLembur = scanner.nextInt();

        // Deklarasi variabel gaji pokok dan gaji lembur
        int gajiPokok = 0;
        double gajiLembur = 0;

        // Menentukan gaji pokok berdasarkan golongan
        if (golongan.equals("A")) {
            gajiPokok = gaji[0];
        } else if (golongan.equals("B")) {
            gajiPokok = gaji[1];
        } else if (golongan.equals("C")) {
            gajiPokok = gaji[2];
        } else {
            System.out.println("Golongan tidak valid!");
            System.exit(0);
        }

        // Menentukan persentase lembur berdasarkan jam lembur
        if (jamLembur == 1) {
            gajiLembur = gajiPokok * persenLembur[0] / 100.0;
        } else if (jamLembur == 2) {
            gajiLembur = gajiPokok * persenLembur[1] / 100.0;
        } else if (jamLembur == 3) {
            gajiLembur = gajiPokok * persenLembur[2] / 100.0;
        } else if (jamLembur == 4) {
            gajiLembur = gajiPokok * persenLembur[3] / 100.0;
        } else if (jamLembur >= 5) {
            gajiLembur = gajiPokok * persenLembur[4] / 100.0;
        }

        // Menghitung total penghasilan
        double totalPenghasilan = gajiPokok + gajiLembur;

        // Output hasil
        System.out.println("\n--- Hasil Perhitungan ---");
        System.out.println("Golongan: " + golongan);
        System.out.println("Gaji Pokok: Rp " + gajiPokok);
        System.out.println("Gaji Lembur: Rp " + gajiLembur);
        System.out.println("Total Penghasilan: Rp " + totalPenghasilan);

        scanner.close();
    }
}
